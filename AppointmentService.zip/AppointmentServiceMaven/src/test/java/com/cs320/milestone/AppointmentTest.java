package com.cs320.milestone;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;
import java.util.Calendar;


public class AppointmentTest {

    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        return cal.getTime();
    }

    @Test
    public void testValidAppointmentCreation() {
        Appointment appt = new Appointment("123", getFutureDate(), "Test appointment");
        assertEquals("123", appt.getAppointmentId());
    }

    @Test
    public void testNullIdThrows() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, getFutureDate(), "Desc");
        });
    }

    @Test
    public void testTooLongIdThrows() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", getFutureDate(), "Desc");
        });
    }

    @Test
    public void testPastDateThrows() {
        Date past = new Date(System.currentTimeMillis() - 10000);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", past, "Desc");
        });
    }

    @Test
    public void testTooLongDescriptionThrows() {
        String longDesc = "A".repeat(51);
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", getFutureDate(), longDesc);
        });
    }

    @Test
    public void testSettersValidate() {
        Appointment appt = new Appointment("123", getFutureDate(), "Okay");
        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(null));
    }
}
