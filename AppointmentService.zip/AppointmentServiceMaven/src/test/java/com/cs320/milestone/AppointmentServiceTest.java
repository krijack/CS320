package com.cs320.milestone;

import org.junit.jupiter.api.Test;


import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {

    private Date getFutureDate(int daysAhead) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, daysAhead);
        return cal.getTime();
    }

    @Test
    public void testAddAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("A10", getFutureDate(2), "New Appt");
        service.addAppointment(appt);
        assertEquals(appt, service.getAppointment("A10"));
    }

    @Test
    public void testAddDuplicateIdThrows() {
        AppointmentService service = new AppointmentService();
        Appointment appt1 = new Appointment("A10", getFutureDate(2), "First");
        Appointment appt2 = new Appointment("A10", getFutureDate(3), "Duplicate");
        service.addAppointment(appt1);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(appt2));
    }

    @Test
    public void testDeleteAppointmentSuccess() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("A20", getFutureDate(4), "To-Delete");
        service.addAppointment(appt);
        service.deleteAppointment("A20");
        assertNull(service.getAppointment("A20"));
    }

    @Test
    public void testDeleteNonexistentIdThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("DOES_NOT_EXIST"));
    }
}
