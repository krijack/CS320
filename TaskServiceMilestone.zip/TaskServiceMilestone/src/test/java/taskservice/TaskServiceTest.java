/**
 * File: TaskServiceTest.java
 * Author: Kristie Jackson
 * Date: 2025-06-01
 * Description: Unit tests for the TaskService class. Validates task creation,
 * deletion, and field updates while ensuring proper exception handling.
 */


package taskservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    @Test
    public void testAddAndPreventDuplicate() {
        TaskService service = new TaskService();
        Task task = new Task("001", "Task One", "Desc One");
        service.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
    }

    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("002", "Task Two", "Desc Two");
        service.addTask(task);
        service.deleteTask("002");
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("002"));
    }

    @Test
    public void testUpdateTask() {
        TaskService service = new TaskService();
        Task task = new Task("003", "Task Three", "Desc Three");
        service.addTask(task);
        service.updateTaskName("003", "Updated Name");
        service.updateTaskDescription("003", "Updated Description");
        assertEquals("Updated Name", task.getName());
        assertEquals("Updated Description", task.getDescription());
    }
}
