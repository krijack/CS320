/**
 * File: TaskTest.java
 * Author: Kristie Jackson
 * Date: 2025-05-30
 * Description: Unit tests for the Task class. Verifies constructor validation
 * and the correct functionality of setter methods.
 */



package taskservice;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testTaskCreation() {
        Task task = new Task("123", "Test Task", "This is a test description");
        assertEquals("123", task.getTaskId());
        assertEquals("Test Task", task.getName());
        assertEquals("This is a test description", task.getDescription());
    }

    @Test
    public void testSetters() {
        Task task = new Task("123", "Old Name", "Old Description");
        task.setName("New Name");
        task.setDescription("New Description");
        assertEquals("New Name", task.getName());
        assertEquals("New Description", task.getDescription());
    }
}
