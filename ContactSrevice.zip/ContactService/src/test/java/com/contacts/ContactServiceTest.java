// ContactServiceTest.java
package com.contacts;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for ContactService. Covers add, delete, and update operations,
 * including error cases.
 */
public class ContactServiceTest {
	private ContactService service;
	private Contact c1, c2;

	@BeforeEach
	void init() {
		service = new ContactService();
		c1 = new Contact("ID1", "John", "Doe", "0123456789", "111 Elm St");
		c2 = new Contact("ID2", "Jane", "Roe", "9876543210", "222 Pine Rd");
	}

	@Test
	void addAndDeleteContact() {
		service.addContact(c1);
		// Adding same ID again should fail
		assertThrows(IllegalArgumentException.class, () -> service.addContact(c1));
		// Delete existing
		service.deleteContact("ID1");
		// Deleting again should fail
		assertThrows(IllegalArgumentException.class, () -> service.deleteContact("ID1"));
	}

	@Test
	void updateContactFields() {
		service.addContact(c2);
		service.updateFirstName("ID2", "Janet");
		service.updateLastName("ID2", "Smith");
		service.updatePhone("ID2", "1234509876");
		service.updateAddress("ID2", "333 Maple Way");

		assertAll("Verify all updated fields", () -> assertEquals("Janet", c2.getFirstName()),
				() -> assertEquals("Smith", c2.getLastName()), () -> assertEquals("1234509876", c2.getPhone()),
				() -> assertEquals("333 Maple Way", c2.getAddress()));
	}

	@Test
	void updateNonexistentContact() {
		assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("NOPE", "Tom"));
	}

	@Test
	void deleteNonexistentContact() {
		assertThrows(IllegalArgumentException.class, () -> service.deleteContact("UNKNOWN"));
	}
}
