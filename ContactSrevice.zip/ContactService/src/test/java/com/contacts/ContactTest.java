// ContactTest.java
package com.contacts;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for the Contact class. Verifies constructor validation and setter
 * constraints.
 */
class ContactTest {

	@Test
	void validConstructionAndGetters() {
		Contact c = new Contact("ID123", "Alice", "Smith", "0123456789", "123 Main St");
		assertEquals("ID123", c.getContactId());
		assertEquals("Alice", c.getFirstName());
		assertEquals("Smith", c.getLastName());
		assertEquals("0123456789", c.getPhone());
		assertEquals("123 Main St", c.getAddress());
	}

	@Test
	void invalidIdTooLong() {
		assertThrows(IllegalArgumentException.class, () -> new Contact("TOO_LONG_ID", "A", "B", "0123456789", "Addr"));
	}

	@Test
	void setFirstNameTooLong() {
		Contact c = new Contact("ID1", "A", "B", "0123456789", "Addr");
		assertThrows(IllegalArgumentException.class, () -> c.setFirstName("ABCDEFGHIJKLMNOP"));
	}

	@Test
	void invalidPhone() {
		// less than 10 digits should fail
		assertThrows(IllegalArgumentException.class, () -> new Contact("ID2", "A", "B", "1234", "Addr"));
	}

	@Test
	void setAddressNull() {
		Contact c = new Contact("ID3", "A", "B", "0123456789", "Good Addr");
		assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
	}

	@Test
	void updateFieldsSuccessfully() {
		Contact c = new Contact("ID4", "A", "B", "0123456789", "Addr");
		c.setFirstName("Bob");
		c.setLastName("Jones");
		c.setPhone("9876543210");
		c.setAddress("456 Oak Lane");
		assertAll(() -> assertEquals("Bob", c.getFirstName()), () -> assertEquals("Jones", c.getLastName()),
				() -> assertEquals("9876543210", c.getPhone()), () -> assertEquals("456 Oak Lane", c.getAddress()));
	}
}
