// ContactService.java
package com.contacts;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    /** Add a new contact; ID must be unique. */
    public void addContact(Contact contact) {
        String id = contact.getContactId();
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("Duplicate ID: " + id);
        }
        contacts.put(id, contact);
    }

    /** Delete an existing contact by ID. */
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("No such contact: " + contactId);
        }
        contacts.remove(contactId);
    }

    /** Update first name for a given contact ID. */
    public void updateFirstName(String contactId, String newFirst) {
        Contact c = getContactOrThrow(contactId);
        c.setFirstName(newFirst);
    }

    /** Update last name for a given contact ID. */
    public void updateLastName(String contactId, String newLast) {
        Contact c = getContactOrThrow(contactId);
        c.setLastName(newLast);
    }

    /** Update phone for a given contact ID. */
    public void updatePhone(String contactId, String newPhone) {
        Contact c = getContactOrThrow(contactId);
        c.setPhone(newPhone);
    }

    /** Update address for a given contact ID. */
    public void updateAddress(String contactId, String newAddress) {
        Contact c = getContactOrThrow(contactId);
        c.setAddress(newAddress);
    }

    private Contact getContactOrThrow(String id) {
        Contact c = contacts.get(id);
        if (c == null) {
            throw new IllegalArgumentException("No such contact: " + id);
        }
        return c;
    }
}

